#!/bin/bash
python3.8 -m venv ./venv
. venv/bin/activate

pip install -r requirements.txt
